1. Create a new GitHub repo.
2. Upload everything in this folder (including the .github folder).
3. Open the Actions tab > Build APK > wait ~5 min.
4. Download "server-connect-apk" from the run, unzip, install app-debug.apk.
